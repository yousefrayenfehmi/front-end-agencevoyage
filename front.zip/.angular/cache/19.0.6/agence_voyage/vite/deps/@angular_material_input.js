import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-XV6BVUUY.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-PQFTEQLF.js";
import "./chunk-XO7BWDAD.js";
import "./chunk-ODME7D2D.js";
import "./chunk-6B7XRRME.js";
import "./chunk-DAGN3SKJ.js";
import "./chunk-MOAI5ZZZ.js";
import "./chunk-C7VT6QD6.js";
import "./chunk-VZJ3324K.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
