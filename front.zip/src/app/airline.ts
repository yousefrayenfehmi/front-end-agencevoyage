
  export interface Airline {
    _id: string;
    name: string;
  }
  
