export interface Airport {
    _id: string;
    name: string;
  }
  